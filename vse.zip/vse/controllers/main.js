const { makeRatingFile, config } = require("../rating");
const { getData, endpoints } = require("../appModules/api");
const staticFile = require("../appModules/http-utils/static-file");

async function mainRouteController(res, publicUrl, extname) {
  const data = await getData(endpoints.games);
  console.log(data);
  await makeRatingFile(config.PATH_TO_RATING_FILE, data);

  res.statusCode = 200;
  staticFile(res, publicUrl, extname);
}
module.exports = mainRouteController;
